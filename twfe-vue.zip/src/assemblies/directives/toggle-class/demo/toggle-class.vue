<template>
  <a class="tw-btn xmain" href="#" v-class:hover="'xdemo'" data-target="h1">hover me to toggle the background of logo</a>
</template>

<style lang="scss">
  h1.xdemo {
    background: #f00;
  }
</style>
