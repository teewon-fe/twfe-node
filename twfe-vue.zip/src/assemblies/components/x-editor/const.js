export const imageExts = ['png', 'jpg', 'jpeg', 'gif', 'bmp']
export const videoExts = ['mp4', 'wmv', 'avi', 'mov']
export const audioExts = ['mp3', 'ogg', 'aac', 'wma', 'wav']
