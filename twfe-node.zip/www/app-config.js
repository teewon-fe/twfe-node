/*
 * 功能: 配置应用依赖的环境变量
 */
window.$app = {
  apiBaseUrl: 'http://192.168.112.179:3000',
  loginPage: '/#/login'
}
