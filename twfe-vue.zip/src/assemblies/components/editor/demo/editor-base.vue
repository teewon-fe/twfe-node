<template>
  <tw-editor>
    <template slot="toolbar-left">工具栏左边内容</template>
    <template slot="toolbar-right">工具栏右边内容</template>
  </tw-editor>
</template>
