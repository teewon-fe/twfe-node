export default {
  components: {
    cutter: {
      expand: '展开',
      collapse: '收起'
    }
  }
}
