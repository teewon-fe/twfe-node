<template>
  <main class="tw-body">
    <div class="tw-body-inner" v-bottom="70">
      首页
    </div>
  </main>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

</style>
