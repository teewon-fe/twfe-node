module.exports = {
  user: 'postgres',
  // host: '172.23.239.158',
  host: '192.168.112.214',
  database: 'twfe',
  password: '123456',
  port: 5432
}