export default {
  components: {
    cutter: {
      expand: 'expand',
      collapse: 'collapse'
    }
  }
}
