export default function numToLetter (val) {
  return String.fromCharCode(65 + parseInt(val))
}
