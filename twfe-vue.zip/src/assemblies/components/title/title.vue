<template>
  <div class="tw-blue-title">
    <h3 class="tw-blue-title-left">标题文本</h3>
    <div class="tw-blue-title-right">标题右侧内容</div>
  </div>
</template>

<script>
export default {
  name: 'twTitle'
}
</script>
